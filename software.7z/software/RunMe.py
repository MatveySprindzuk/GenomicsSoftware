#!/usr/bin/python
# Software tool for fetching FASTQ files from the SRA accession ID number, converting, indexing and producing SNP variant call report
# Matvey Sprindzuk, msprindzhuk@mail.ru
# You may need to have fastq-dump tool from the SRAToolkit in the same directory to run all things smoothly, download binary from http://ftp-trace.ncbi.nlm.nih.gov/sra/sdk/2.8.1/sratoolkit.2.8.1-ubuntu64.tar.gz
# http://ftp-trace.ncbi.nlm.nih.gov/sra/sdk/2.8.1/sratoolkit.2.8.1-mac64.tar.gz or http://ftp-trace.ncbi.nlm.nih.gov/sra/sdk/2.8.1/sratoolkit.2.8.1-win64.zip
# Try SRR1174825 on widget input to test software functionality
# Do not forget to put all tools to the environment path, see http://askubuntu.com/questions/63250/how-to-set-environmental-variable-path
# Software has been tested on Linux Mint 18.1 edition.

import gi
from gi.repository import Gtk # GTK GUI module
import subprocess # module for calling external software
from executor import execute # subprocess module wrapper, run "sudo pip install executor" if not have it yet

class Bioinformatics:
    def __init__(self):
        window = Gtk.Window()
        window.set_size_request(200, 100)
        window.set_title("Tuberculosis Belarus")
        window.connect("delete_event", Gtk.main_quit)

        vbox = Gtk.VBox(False, 0)
        window.add(vbox)
        self.entry = Gtk.Entry()
        self.entry.set_max_length(50)
        self.entry.set_text("SRA accession number")
        vbox.pack_start(self.entry, True, True, 0)

        buttonscript = Gtk.Button(label="Download", stock=None)
        buttonscript.connect("clicked", self.runlinuxshell)
        vbox.pack_start(buttonscript, True, True, 0)
        
        buttonalignment = Gtk.Button(label="Align", stock=None)
        buttonalignment.connect("clicked", self.alignment)
        vbox.pack_start(buttonalignment, True, True, 0)
        
        buttonconvert = Gtk.Button(label="Convert and index", stock=None)
        buttonconvert.connect("clicked", self.convert)
        vbox.pack_start(buttonconvert, True, True, 0)
        
        buttongeneratereport = Gtk.Button(label="Call variants", stock=None)
        buttongeneratereport.connect("clicked", self.generatereport)
        vbox.pack_start(buttongeneratereport, True, True, 0)
        
 
        button = Gtk.Button(stock=Gtk.STOCK_CLOSE)
        button.connect("clicked", Gtk.main_quit)
        vbox.pack_start(button, True, True, 0)
        window.show_all()

    def runlinuxshell (self, widget):   # main function for processing widget input and executing linux bash script
		
        text_input = self.entry.get_text()
        text_file = open("SRAIdFromPythonInput.txt", "w")
        text_file.write(text_input)
        text_file.close()
        execute('bash ./get_fastq_from_python_sra.sh')
        
    def alignment (self, widget):   # calling alignment bash script
      
        execute('bash ./aligner_single.sh')
        
    def convert (self, widget):   # running converting and indexing bash script
      
        execute('bash ./convert.sh')
        
    def generatereport (self, widget):   # calling variant calling and report bash script
      
        execute('bash ./generate_report.sh')
        

	    
    def main(self):
        Gtk.main()

if __name__ == "__main__":
    sub = Bioinformatics()
    sub.main()

