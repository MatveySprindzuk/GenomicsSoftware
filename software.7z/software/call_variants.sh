#!/bin/bash
# data processing step is based on the tutorial http://www.htslib.org/workflow/

samtools view  -bS aligned_sam_result.sam > unsorted_bam.bam # coverting to bam


samtools sort unsorted_bam.bam file.sorted


samtools index file.sorted.bam # indexing
 










